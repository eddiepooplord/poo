function showImage(){
    var image=document.getElementById('reed');
    image.src = "images/reed.jpg";
}

function showScienceImage(){
    var image=document.getElementById('science');
    image.src = "images/science.jpg";
}

function showLitImage(){
    var image=document.getElementById('lit');
    image.src = "images/lit.jpg";
}

function showWebImage(){
    var image=document.getElementById('web');
    image.src = "images/web.jpg";
}

function showbtd6Image(){
    var image=document.getElementById('btd6');
    image.src = "images/btd6.jpg";
}

function showNKImage() {
    var img = document.getElementById('nobodyknows');
    img.src = 'images/nobodyknows.jpg';
}